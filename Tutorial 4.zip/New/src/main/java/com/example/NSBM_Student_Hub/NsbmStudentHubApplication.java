package com.example.NSBM_Student_Hub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NsbmStudentHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(NsbmStudentHubApplication.class, args);
	}

}
